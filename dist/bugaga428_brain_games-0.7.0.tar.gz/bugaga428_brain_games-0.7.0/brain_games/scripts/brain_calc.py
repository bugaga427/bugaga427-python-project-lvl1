from brain_games.games.calc import calc


def main():
    calc()


if __name__ == '__main__':
    main()

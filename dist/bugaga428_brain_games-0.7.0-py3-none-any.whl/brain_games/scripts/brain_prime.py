from brain_games.games.prime import prime


def main():
    prime()


if __name__ == "__main__":
    main()

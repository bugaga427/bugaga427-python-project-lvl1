from brain_games.cli import greet, welcome_user


def main():
    greet()
    print()
    welcome_user()


if __name__ == '__main__':
    main()

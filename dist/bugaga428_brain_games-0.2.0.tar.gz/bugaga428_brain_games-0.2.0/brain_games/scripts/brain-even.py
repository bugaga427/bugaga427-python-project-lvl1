from brain_games.cli import welcome_user, greet
from brain_games.game_logic import even

def main():
    even()

if __name__ == '__main__':
    main()
